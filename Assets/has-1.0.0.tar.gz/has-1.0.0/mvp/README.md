# HAS (Hybrid Animal Synthesis) MVP

## Table of Contents

- [Milestone Status](#milestone-status)
- [Surprises and Challenges](#surprises-and-challenges)
- [Design and Concept Changes](#design-and-concept-changes)
- [Technical Changes](#technical-changes)
- [Collaboration](#collaboration)

## Milestone Status

The primary goal of the MVP milestone was the max patch implementing minimal hybrid functionality, [which has been completed](mvp_final.maxpat). This patch has the following: 
* 2 sound sources (a vocal cord modeling approach and a karplus-strong blown tube approach)
* 2 vocal tract (cow, general bird)
* 2 environments (small room, large cave)

This is similar to the initial goals of the MVP, with the exception of a avian sound source due to the challenges outlined below. However, we also implemented some prototype-UI input methods that were not originally planned for the MVP, which are also outlined below.

## Surprises and Challenges

The main challenge, which didn't necessarily come as a surprise as we outlined the potential for this to happen in the concept pitch, was the stability of the system. In our attempts to transcribe various models and convert them to Max patches from research papers and books, we many times encountered scenarios where the feedback loops diverged, resulting in positive feedback and thus unusable audio. This took several different attempts at models and ultimately ended up in being unable to incorporate some physical models into the current MVP as it stands. Nevertheless, we will be constantly working on making more models stable over time so that we can build them into our software in the upcoming beta version.

## Design and Concept Changes

There are no major changes that were made in terms of the inception of the idea; it has been steadily the same concept of hybrid animal synthesis. We discussed changing the form of input to essentially allow the user to have more control over the shape of the sound, as our original model in the pitch did not have any capacity for this. To address a more controllable input, we plan to implement drawable boxes where the x-axis represents time and y-axis represents the variable of control like amplitude variance or pitch variance. The idea is to not let this dictate what the sound is too much, per se, but more as a customizable shape of a sound such that you can achieve a variety of sounds in the same domain of the hybrid type of animal.

## Technical Changes

As expected, using Max has allowed us to quickly sketch up general systems representing some physical models, but its usefulness quickly hit its limit when it came to implementing core programming practices such as variable and function use, as well as our design concept for UI. As such, looking towards the beta version, we will be attempting to translate our MVP into pure C++ code, which, despite challenging, will allow for much more flexibility and modularity than just using a Max patch would.

## Collaboration

Working as a group has been extremely smooth. Everyone has been contributing with different emphases based on our individual abilities and strengths and that resulted in everyone making around equal contributions in an effective sense.
