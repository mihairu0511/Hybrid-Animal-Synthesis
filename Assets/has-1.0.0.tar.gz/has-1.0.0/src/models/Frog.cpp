/*
  ==============================================================================

    Frog.cpp
    Created: 2 Dec 2024 3:21:09am
    Author:  Jack Hayley

  ==============================================================================
*/

#include "Frog.h"

void Frog::generateSound(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    Mammal::generateSound(buffer, numSamples, params);
    for (int i = 0; i < numSamples; ++i) {
        buffer[i] *= 16;
    }
}

juce::String Frog::toString() const
{
    return "Frog";
}
