/*
  ==============================================================================

    AbstractModel.h
    Created: 9 Oct 2024 2:37:43pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "parts/Constants.h"
#include "juce_core/juce_core.h"

#pragma once

class AbstractModel {
    
    
public:
    virtual ~AbstractModel() = 0;
    
    virtual juce::String toString() const = 0;
};
