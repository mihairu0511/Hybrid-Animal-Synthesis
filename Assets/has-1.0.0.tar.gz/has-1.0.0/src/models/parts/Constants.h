/*
  ==============================================================================

    Constants.h
    Created: 9 Oct 2024 2:29:09pm
    Author:  Jack Hayley

  ==============================================================================
*/

#pragma once


enum PartType
{
    SoundSource,
    VocalTract,
    Environment
};
