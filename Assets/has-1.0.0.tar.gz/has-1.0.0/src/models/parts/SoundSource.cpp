/*
  ==============================================================================

    SoundSource.cpp
    Created: 24 Oct 2024 1:48:01pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "SoundSource.h"

SoundSource::SoundSource() {}
SoundSource::~SoundSource() {}

void SoundSource::process(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    generateSound(buffer, numSamples, params);
}
