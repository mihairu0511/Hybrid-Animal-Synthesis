/*
  ==============================================================================

    UserParams.h
    Created: 25 Oct 2024 9:33:49am
    Author:  Jack Hayley

  ==============================================================================
*/

#pragma once

#include "juce_core/juce_core.h"
#include <juce_graphics/juce_graphics.h>
#include <juce_data_structures/juce_data_structures.h>

class UserParams {
    
public:
    
    UserParams(double sampleRate = 44100.0f);
    ~UserParams();
        
    int updateElapsedTime(double dt);
    float lookaheadElapsedTime(double dt);
    float getElapsedTime();
    void resetElapsedTime();
    
    float getCurrentAmplitude(double dt);
    float getCurrentPitch(double dt);
    
    juce::Array<juce::Point<float>> getAmplitudePoints();
    juce::Array<juce::Point<float>> getPitchPoints();
    
    
    
    void setAmplitudePath(const juce::Array<juce::Point<float>>& points);
    void setPitchPath(const juce::Array<juce::Point<float>>& points);
    
    void save(juce::ValueTree& state);
    void load(juce::ValueTree& state);
    
    double getSampleRate();
    
    
    void initiate();
    bool isFinished();

private:
    double elapsedTime = 2.0f;
    double totalTime = 2.0f;
    
    float sampleRate;
    
    juce::Path amplitude;
    juce::Path pitch;
    
    juce::Array<juce::Point<float>> amplitudePoints;
    juce::Array<juce::Point<float>> pitchPoints;
    
    float getY(juce::Path path, float x);
    juce::Array<juce::Point<float>> getPathPoints(juce::Path path);
};

