/*
  ==============================================================================

    AbstractPart.h
    Created: 9 Oct 2024 1:07:46pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include <juce_core/juce_core.h>
#include "Constants.h"
#include "UserParams.h"

#pragma once
class AbstractPart {
public:
    virtual ~AbstractPart() = 0;
    
    virtual PartType getType() = 0;
    
    static void addInstance(std::shared_ptr<AbstractPart> instance);
    static void addInstance(std::shared_ptr<AbstractPart> instance, PartType type);
    static juce::Array<std::shared_ptr<AbstractPart>>& getInstancesOfType(PartType type);
    
    virtual void process(float* buffer, int numSamples, std::shared_ptr<UserParams> params) = 0;
    
    juce::String toString() { return "Part"; };
    
protected:
    AbstractPart();
    
    

    
private:
    static juce::HashMap<PartType, juce::Array<std::shared_ptr<AbstractPart>>> instances;
};
