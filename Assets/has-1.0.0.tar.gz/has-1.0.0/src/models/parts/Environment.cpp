/*
  ==============================================================================

    Environment.cpp
    Created: 24 Oct 2024 1:48:52pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "Environment.h"

Environment::~Environment() {}

void Environment::process(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    applyEffectsToSound(buffer, numSamples, params);
}
