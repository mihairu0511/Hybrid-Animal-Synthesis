/*
  ==============================================================================

    Frog.h
    Created: 2 Dec 2024 3:21:09am
    Author:  Jack Hayley

  ==============================================================================
*/

#pragma once

#include "Mammal.h"

class Frog : public Mammal {

public:
    void generateSound(float* buffer, int numSamples, std::shared_ptr<UserParams> params) override;
    
    juce::String toString() const override;
    
protected:
    double getFrequencyBase() const override { return 5.0; };
};
