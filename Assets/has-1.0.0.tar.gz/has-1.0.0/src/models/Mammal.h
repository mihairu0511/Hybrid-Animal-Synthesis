/*
  ==============================================================================

    Mammal.h
    Created: 24 Oct 2024 1:50:10pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include <juce_dsp/juce_dsp.h>

#include "AbstractModel.h"
#include "parts/SoundSource.h"
#include "parts/VocalTract.h"

#pragma once
class Mammal : public AbstractModel, public SoundSource, public VocalTract {
    
    
public:
    Mammal();
    ~Mammal();
        
    virtual void generateSound(float* buffer, int numSamples, std::shared_ptr<UserParams> params) override;
    virtual void modifySoundThroughTract(float* buffer, int numSamples, std::shared_ptr<UserParams> params) override;
    
    virtual juce::String toString() const override;

protected:
    virtual double getFrequencyBase() const override { return 75.0; };
    double getFrequencyRange() const override { return 25.0; };
    
    double getCordWidth() const { return 10.0; };
    double getCordNoise() const { return 0.5; };
    double getCordRipple() const { return 1.0; };
    
    double getTractBase() const { return 338.0; };
    double getTractLength() const { return 124.0; };
    double getTractRes() const { return 44.4; };
    double getTractBaseMod() const { return 180.0; };
    double getTractLengthMod() const { return 41.0; };
    double getTractResMod() const { return 26.0; };

private:
//    juce::Random noise;
    
    std::vector<std::unique_ptr<juce::dsp::IIR::Filter<float>>> tractFilters;
    int numFilters = 8;
    
    void phasor(float* buffer, int numSamples, std::shared_ptr<UserParams> params);
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Mammal);
};
