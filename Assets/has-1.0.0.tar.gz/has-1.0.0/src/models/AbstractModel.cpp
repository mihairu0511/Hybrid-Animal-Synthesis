/*
  ==============================================================================

    AbstractModel.cpp
    Created: 9 Oct 2024 2:37:43pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "AbstractModel.h"

AbstractModel::~AbstractModel() {} 
