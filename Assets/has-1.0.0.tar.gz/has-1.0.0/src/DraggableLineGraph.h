/*
  ==============================================================================

    DraggableLineGraph.h
    Created: 24 Nov 2024 2:09:15pm
    Author:  Mikhail Titov

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>

class DraggableLineGraph : public juce::Component
{
public:
    DraggableLineGraph();
    ~DraggableLineGraph() override = default;

    void paint(juce::Graphics& g) override;
    void mouseDown(const juce::MouseEvent& event) override;
    void mouseDrag(const juce::MouseEvent& event) override;
    void mouseUp(const juce::MouseEvent& event) override;

    // Get the array of points (time/amplitude coordinates)
    juce::Array<juce::Point<float>> getPointsCoordinates() const;
    void setPoints(juce::Array<juce::Point<float>> &newPoints);

    // Generates an array of interpolated y-values for x positions
    juce::Array<float> getYValuesForXPositions(int numSamples, float startX, float endX) const;

private:
    // Helper function to interpolate y for a given x
    float getYForX(float x) const;

    // Convert time/amplitude to pixel coordinates
    juce::Point<float> scaleToPixel(const juce::Point<float>& point) const;

    // Convert pixel coordinates to time/amplitude
    juce::Point<float> scaleToDomain(const juce::Point<float>& pixelPoint) const;

    juce::Array<juce::Point<float>> points; // Time (x: 0-2), Amplitude (y: 0-1)
    int selectedPoint = -1; // Index of the selected point

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DraggableLineGraph)
};

