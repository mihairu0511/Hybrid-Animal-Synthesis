/*
  ==============================================================================

    Modules.h
    Created: 25 Oct 2024 3:49:44pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "models/Models.h"
#include "juce_core/juce_core.h"
#include "juce_data_structures/juce_data_structures.h"

#pragma once

class Modules {
    std::shared_ptr<class SoundSource> source;
    std::shared_ptr<class VocalTract> tract;
    std::shared_ptr<class Environment> env;
    
    juce::Array<std::shared_ptr<AbstractModel>> models;
    
    
public:
    Modules();
    
    void process(float* buffer, int numSamples, std::shared_ptr<UserParams> params);
    
    void setSource(std::shared_ptr<AbstractPart> source);
    void setTract(std::shared_ptr<AbstractPart> tract);
    void setEnv(std::shared_ptr<AbstractPart> env);
    
    std::shared_ptr<AbstractModel> getSource();
    std::shared_ptr<AbstractModel> getTract();
    std::shared_ptr<AbstractModel> getEnv();

    void updatePhase(double sampleRate, int numSamples);
    
    void save(juce::ValueTree& state);
    void load(juce::ValueTree& state);
    
private:
    // TEMP (REMOVE LATER)
    double phase = 0.0;  // Persistent phase across calls

    void generateSineWave(float* buffer, int numSamples, std::shared_ptr<UserParams> params);
    void applyAmplitudeEnvelope(float* buffer, int numSamples, std::shared_ptr<UserParams> params);
    
    
};
