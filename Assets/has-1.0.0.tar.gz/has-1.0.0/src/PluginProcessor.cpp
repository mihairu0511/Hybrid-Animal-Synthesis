/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "models/parts/SoundSource.h"

//==============================================================================
HasAudioProcessor::HasAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       )
#endif
{
    modules = std::make_unique<Modules>();
}

HasAudioProcessor::~HasAudioProcessor()
{
    if (userParams)
    {
        userParams.reset();
    }
}

//==============================================================================
const juce::String HasAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool HasAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool HasAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool HasAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double HasAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int HasAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int HasAudioProcessor::getCurrentProgram()
{
    return 0;
}

void HasAudioProcessor::setCurrentProgram (int index)
{
}

const juce::String HasAudioProcessor::getProgramName (int index)
{
    return {};
}

void HasAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void HasAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // Use this method as the place to do any pre-playback
    // initialisation that you need..
    if (userParams)
        DBG("UP already initialized.");
    else
    {
        DBG("UP initializing.");
        userParams = std::make_shared<UserParams>(sampleRate);
    }
}

void HasAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool HasAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void HasAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());
    
    // Handle MIDI...?
    
    for (const auto metadata : midiMessages)
    {
        auto message = metadata.getMessage();
        if (message.isNoteOn() && message.getFloatVelocity() > 0.0f && message.getNoteNumber() == 60) // C3 note
        {
            userParams->initiate();
            break;
        }
    }

    // This is the place where you'd normally do the guts of your plugin's
    // audio processing...
    // Make sure to reset the state if your inner loop is processing
    // the samples and the outer loop is handling the channels.
    // Alternatively, you can process t he samples with the channels
    // interleaved by keeping the same state.
        
    // Doing mono output (FOR NOW)
    for (int channel = 0; channel < 1; ++channel)
    {
        float* channelData = buffer.getWritePointer (channel); // auto*?
        modules->process(channelData, buffer.getNumSamples(), userParams);
    }
    
    // Copy channel 0 data to remaining output channels
    for (int channel = 1; channel < totalNumOutputChannels; ++channel)
    {
        for (int i = 0; i < buffer.getNumSamples(); ++i) {
            buffer.setSample(channel, i, buffer.getSample(0, i));
        }
        
    }

    modules->updatePhase(userParams->getSampleRate(), buffer.getNumSamples());
//    currentPhase = std::fmod(currentPhase + buffer.getNumSamples() * diff, 2.0f * juce::MathConstants<float>::pi);
    userParams->updateElapsedTime(buffer.getNumSamples());
    
    //Process the wave information for visual
    
    auto* channelData = buffer.getReadPointer(0); 

    if (waveformBuffer.getNumChannels() != 1 || waveformBuffer.getNumSamples() != waveformBufferSize)
            waveformBuffer.setSize(1, waveformBufferSize);

    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        waveformBuffer.setSample(0, waveformBufferWritePos, channelData[i]);
        waveformBufferWritePos = (waveformBufferWritePos + 1) % waveformBufferSize;
    }
}

//==============================================================================
bool HasAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* HasAudioProcessor::createEditor()
{
    return new HasAudioProcessorEditor (*this);
}

//==============================================================================
void HasAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
    juce::ValueTree state("PluginState");
    
    // Store userParams state
    if (userParams)
        userParams->save(state);
    
    if (modules)
        modules->save(state);
    
    std::unique_ptr<juce::XmlElement> xml = state.createXml();
    copyXmlToBinary(*xml, destData);
}

void HasAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    
    DBG("Attempting state retrival");
    if (xml && xml->hasTagName("PluginState"))
    {
        juce::ValueTree state = juce::ValueTree::fromXml(*xml);
        DBG("XML RECIEVED: " << state.toXmlString());
        
        if (userParams)
            userParams->load(state);
        
        if (modules)
            modules->load(state);
        DBG("State constructed successfully");
    }
    notify();
}
//==============================================================================

void HasAudioProcessor::notify()
{
    DBG("$ Attempting to notify PE");
    DBG("$ HASAP instance address from HASAP: " << reinterpret_cast<uintptr_t>(this));
    sendChangeMessage();
}

void HasAudioProcessor::initSound(const juce::Array<juce::Point<float>>& amplitudePoints, const juce::Array<juce::Point<float>>& pitchPoints)
{
    if (userParams)
    {
        updatePaths(amplitudePoints, pitchPoints);
        userParams->initiate();
    }
}

void HasAudioProcessor::updatePaths(const juce::Array<juce::Point<float>>& amplitudePoints, const juce::Array<juce::Point<float>>& pitchPoints)
{
    userParams->setAmplitudePath(amplitudePoints);
    userParams->setPitchPath(pitchPoints);
}


void HasAudioProcessor::setSoundSource(int idx)
{
    DBG("Setting sound source to " << AbstractPart::getInstancesOfType(PartType::SoundSource)[idx]->toString());
    modules->setSource(AbstractPart::getInstancesOfType(PartType::SoundSource)[idx]);
}

void HasAudioProcessor::setVocalTract(int idx)
{
    DBG("Setting vocal tract to " << AbstractPart::getInstancesOfType(PartType::VocalTract)[idx]->toString());
    modules->setTract(AbstractPart::getInstancesOfType(PartType::VocalTract)[idx]);
}


juce::Array<juce::Point<float>> HasAudioProcessor::getPathPoints(juce::String type)
{
    if (userParams && type == "a")
    {
        return userParams->getAmplitudePoints();
    } else if (userParams && type == "p")
    {
        return userParams->getPitchPoints();
    } else {
        if (!userParams)
            DBG("UP DOESNT EXIST... WHY");
        return juce::Array<juce::Point<float>>();
    }
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new HasAudioProcessor();
}


