/*
  ==============================================================================

    DraggableLineGraph.cpp
    Created: 24 Nov 2024 2:09:15pm
    Author:  Mikhail Titov

  ==============================================================================
*/

#include "DraggableLineGraph.h"

DraggableLineGraph::DraggableLineGraph()
{
    // Initialize points in time (x: 0-2 seconds) and amplitude (y: 0-1)
    points.add({ 0.1f, 0.0f }); // Time: 0s, Amplitude: 0.5
    points.add({ 0.5f, 0.5f }); // Time: 0.5s, Amplitude: 0.8
    points.add({ 1.0f, 0.7f }); // Time: 1s, Amplitude: 0.2
    points.add({ 1.5f, 0.3f }); // Time: 1.5s, Amplitude: 0.7
    points.add({ 1.9f, 0.0f }); // Time: 2s, Amplitude: 0.4
}

void DraggableLineGraph::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colours::darkgrey); // Background color
    
    g.setColour(juce::Colours::white); // Set the border color
    g.drawRect(getLocalBounds(), 2);   // Draw the border with a thickness of 2 pixels

    // Draw axes
    g.setColour(juce::Colours::white);
    g.drawLine(0, getHeight(), getWidth(), getHeight()); // X-axis
    g.drawLine(0, 0, 0, getHeight()); // Y-axis

    // Draw lines connecting the points
    g.setColour(juce::Colours::lightblue);
    for (int i = 0; i < points.size() - 1; ++i)
    {
        juce::Point<float> p1 = scaleToPixel(points[i]);
        juce::Point<float> p2 = scaleToPixel(points[i + 1]);
        g.drawLine(p1.getX(), p1.getY(), p2.getX(), p2.getY(), 2.0f);
    }

    // Draw points
    for (auto& point : points)
    {
        juce::Point<float> pixelPoint = scaleToPixel(point);
        g.fillEllipse(pixelPoint.getX() - 5, pixelPoint.getY() - 5, 10, 10); // Draw points as circles
    }
}

void DraggableLineGraph::mouseDown(const juce::MouseEvent& event)
{
    juce::Point<float> mousePosition = { (float)event.x, (float)event.y };

    // Check if the mouse click is close to any point
    for (int i = 0; i < points.size(); ++i)
    {
        if (scaleToPixel(points[i]).getDistanceFrom(mousePosition) < 10)
        {
            selectedPoint = i; // Store the index of the selected point
            return;
        }
    }

    selectedPoint = -1;
}

void DraggableLineGraph::mouseDrag(const juce::MouseEvent& event)
{
    if (selectedPoint >= 0 && selectedPoint < points.size())
    {
        // Scale mouse position back to time/amplitude space
        juce::Point<float> newPoint = scaleToDomain({ (float)event.x, (float)event.y });

        // Clamp values to stay within 0-2 for x (time) and 0-1 for y (amplitude)
        newPoint.setX(juce::jlimit(0.0f, 2.0f, newPoint.getX()));
        newPoint.setY(juce::jlimit(0.0f, 1.0f, newPoint.getY()));

        points.set(selectedPoint, newPoint); // Update the selected point
        repaint();
    }
}

void DraggableLineGraph::mouseUp(const juce::MouseEvent&)
{
    selectedPoint = -1; // Reset selection
}

juce::Array<juce::Point<float>> DraggableLineGraph::getPointsCoordinates() const
{
    return points; // Return the array of points (each point contains x and y)
}

juce::Array<float> DraggableLineGraph::getYValuesForXPositions(int numSamples, float startX, float endX) const
{
    juce::Array<float> yValues;
    float xStep = (endX - startX) / (numSamples - 1);

    for (int i = 0; i < numSamples; ++i)
    {
        float x = startX + i * xStep;
        float y = getYForX(x);
        yValues.add(y);
    }

    return yValues;
}

float DraggableLineGraph::getYForX(float x) const
{
    for (int i = 0; i < points.size() - 1; ++i)
    {
        if (points[i].getX() <= x && x <= points[i + 1].getX())
        {
            float x1 = points[i].getX();
            float x2 = points[i + 1].getX();
            float y1 = points[i].getY();
            float y2 = points[i + 1].getY();
            return y1 + (y2 - y1) * (x - x1) / (x2 - x1);
        }
    }

    return points.getLast().getY();
}

juce::Point<float> DraggableLineGraph::scaleToPixel(const juce::Point<float>& point) const
{
    float x = juce::jmap<float>(point.getX(), 0.0f, 2.0f, 0.0f, (float)getWidth());
    float y = juce::jmap<float>(point.getY(), 0.0f, 1.0f, (float)getHeight(), 0.0f);
    return { x, y };
}

juce::Point<float> DraggableLineGraph::scaleToDomain(const juce::Point<float>& pixelPoint) const
{
    float time = juce::jmap<float>(pixelPoint.getX(), 0.0f, (float)getWidth(), 0.0f, 2.0f);
    float amplitude = juce::jmap<float>(pixelPoint.getY(), (float)getHeight(), 0.0f, 0.0f, 1.0f);
    return { time, amplitude };
}

void DraggableLineGraph::setPoints(juce::Array<juce::Point<float>> &newPoints)
{
    if (newPoints.size() < 5)
    {
        DBG("# of points is invalid: " + std::to_string(newPoints.size()));
        return;
    }
    
    
//    while (newPoints.size() > 6)
//    {
//        DBG("# Removing point " << newPoints[0].getX() << " " << newPoints[0].getY());
//        newPoints.remove(0);
//    }
    
    DBG("# of points is valid, repainting: " + std::to_string(newPoints.size()));
    points = newPoints;
    repaint();
}
