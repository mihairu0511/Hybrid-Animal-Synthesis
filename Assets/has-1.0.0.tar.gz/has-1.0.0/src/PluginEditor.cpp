/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
HasAudioProcessorEditor::HasAudioProcessorEditor (HasAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    is_updated = false;
    
    DBG("PE constructor checkpoint???");
    DBG("PTS -> " << audioProcessor.getPathPoints("a").size());
    addAndMakeVisible(initButton);
    const juce::Array<juce::Point<float>>& amplitudePoints = amplitudeGraph.getPointsCoordinates();
    const juce::Array<juce::Point<float>>& pitchPoints = pitchGraph.getPointsCoordinates();
    initButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    initButton.addListener(this);
    
    addAndMakeVisible(cowSourceButton);
    cowSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    cowSourceButton.addListener(this);
    
    addAndMakeVisible(cowTractButton);
    cowTractButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    cowTractButton.addListener(this);
    
    addAndMakeVisible(birdSourceButton);
    birdSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    birdSourceButton.addListener(this);
    
    addAndMakeVisible(birdTractButton);
    birdTractButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    birdTractButton.addListener(this);
    
    addAndMakeVisible(frogSourceButton);
    frogSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    frogSourceButton.addListener(this);
    
//    addAndMakeVisible(caveButton);
    caveButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    caveButton.addListener(this);

//    addAndMakeVisible(f0Slider);
    f0Slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    
//    addAndMakeVisible(rangeSlider);
    rangeSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    
//    addAndMakeVisible(gainSlider);
    gainSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    gainSlider.setSliderStyle(juce::Slider::LinearVertical);  // Make it vertical
    
    addAndMakeVisible(amplitudeGraph);
    addAndMakeVisible(pitchGraph);


    setSize(800, 350);
    
    // Change listener for de processor
    audioProcessor.addChangeListener(this);
    
    DBG("HASAP instance address from PE: " << reinterpret_cast<uintptr_t>(&audioProcessor));
//    updateUI();

    // Start the timer to refresh the waveform display at 30 Hz
    startTimerHz(30);  // Starts the timer to call `timerCallback()` every 1/30th of a second
    
}

HasAudioProcessorEditor::~HasAudioProcessorEditor()
{
    initButton.removeListener(this);
    
    cowSourceButton.removeListener(this);
    cowTractButton.removeListener(this);
    birdSourceButton.removeListener(this);
    birdTractButton.removeListener(this);
    frogSourceButton.removeListener(this);
    caveButton.removeListener(this);
    
    // Change listener for de processor
    audioProcessor.removeChangeListener(this);
    
    stopTimer();
    
    
}

void HasAudioProcessorEditor::timerCallback()
{
    waveformPath.clear();

        // Start the path at the left side of the display area
    waveformPath.startNewSubPath(200, getHeight() / 2);
    auto width = 450;  // Adjust for the area allocated for other UI
    auto height = 150;
    auto* bufferData = audioProcessor.waveformBuffer.getReadPointer(0);
    // Plot the waveform from the circular buffe
    for (int i = 0; i < audioProcessor.waveformBufferSize; ++i)
    {
        // Map the sample amplitude to the vertical position
        float sample = bufferData[(audioProcessor.waveformBufferWritePos + i) % audioProcessor.waveformBufferSize];
        float y = juce::jmap(sample, -1.0f, 1.0f, (float)height, 0.0f) + 190;
            // Map the sample index to the horizontal position
        float x = juce::jmap(i, 0, audioProcessor.waveformBufferSize - 1, 200, width + 200); // Starts at x=200
        waveformPath.lineTo(x, y);
    }
    repaint(); // Request a paint call to update the display
    
    // Get graph coords?
    if (is_updated)
        audioProcessor.updatePaths(amplitudeGraph.getPointsCoordinates(), pitchGraph.getPointsCoordinates());
    else
        updateUI();
        
}

//==============================================================================
void HasAudioProcessorEditor::paint (juce::Graphics& g)
{
    // Fill the background
    g.fillAll(getLookAndFeel().findColour(juce::ResizableWindow::backgroundColourId));
    
    g.setColour(juce::Colours::grey);
    g.fillRect(650, 0, 200, 400);  // Right sidebar area
    
    g.setColour(juce::Colours::black);
    g.fillRect(0, 0, getWidth(), getHeight() / 2 + 10);

    g.setColour(juce::Colours::grey);
    g.fillRect(0, 0, 200, 400);  // Left sidebar area

    // Draw dividing lines
    g.setColour(juce::Colours::black);
    int line1Y = getHeight() / 4;
    int line2Y = getHeight() / 2;
    int line3Y = (3 * getHeight()) / 4;
    g.drawLine(0, line1Y, 200, line1Y, 4.0f);
    g.drawLine(0, line2Y, 200, line2Y, 4.0f);
    g.drawLine(0, line3Y, 200, line3Y, 4.0f);

    // Draw text labels
    g.setColour(juce::Colours::black);
    g.setFont(16.0f);
//    g.drawFittedText("f0", 155, 280, 40, 20, juce::Justification::centred, 1);
//    g.drawFittedText("range", 155, 320, 40, 20, juce::Justification::centred, 1);

    g.setColour(juce::Colours::cyan); // Set color for the waveform
    g.strokePath(waveformPath, juce::PathStrokeType(1.0f)); // Draw the path with a thickness of 1.0f
}

void HasAudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
    initButton.setBounds(695, 230, 90, 90);
    
    cowSourceButton.setBounds(10, 10, 85, 65);
    cowTractButton.setBounds(105, 10, 85, 65);
    birdSourceButton.setBounds(10, 100, 85, 65);
    birdTractButton.setBounds(105, 100, 85, 65);
    frogSourceButton.setBounds(10, 185, 85, 65);
    caveButton.setBounds(105, 185, 85, 65);
    
    f0Slider.setBounds(10, 275, 150, 30);
    rangeSlider.setBounds(10, 315, 150, 30);
    gainSlider.setBounds(640, 210, 70, 130);
    
    amplitudeGraph.setBounds(215, 15, 275, 155);
    pitchGraph.setBounds(510, 15, 275, 155);
}



//==============================================================================
void HasAudioProcessorEditor::buttonClicked(juce::Button* button)
{
    DBG("Some button pressed");
    if (button == &initButton)
    {
        DBG("Correct button pressed");
        auto amplitude = amplitudeGraph.getPointsCoordinates();
        auto pitch = pitchGraph.getPointsCoordinates();
        for (const auto& point : amplitude)
            {
                DBG("Amplitude: (" << point.getX() << ", " << point.getY() << ")");
            }
        
        for (const auto& point : pitch)
            {
                DBG("Pitch: (" << point.getX() << ", " << point.getY() << ")");
            }
        audioProcessor.initSound(amplitude, pitch);
    }
    
    // COW - SOURCE
    if (button == &cowSourceButton) {
        DBG("BTN -> COW - SOURCE");
        cowSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::green);
        birdSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
        frogSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
        audioProcessor.setSoundSource(0);
    }
    
    // COW - TRACT
    if (button == &cowTractButton) {
        DBG("BTN -> COW - TRACT");
        cowTractButton.setColour(juce::TextButton::buttonColourId, juce::Colours::green);
        birdTractButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
        audioProcessor.setVocalTract(0);
        
    }
    
    // BIRD - SOURCE
    if (button == &birdSourceButton) {
        DBG("BTN -> BIRD - SOURCE");
        birdSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::green);
        cowSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
        frogSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
        audioProcessor.setSoundSource(1);
        
    }
    
    // BIRD - TRACT
    if (button == &birdTractButton) {
        DBG("BTN -> BIRD - TRACT");
        birdTractButton.setColour(juce::TextButton::buttonColourId, juce::Colours::green);
        cowTractButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
        audioProcessor.setVocalTract(1);
    }
    
    // FROG - SOURCE
    if (button == &frogSourceButton) {
        DBG("BTN -> FROG - SOURCE");
        frogSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::green);
        cowSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
        birdSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
        audioProcessor.setSoundSource(2);
    }
    
    if (button == &caveButton) {
        caveButton.setColour(juce::TextButton::buttonColourId, juce::Colours::green);
        frogSourceButton.setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    }
}

void HasAudioProcessorEditor::sliderValueChanged(juce::Slider* slider)
{
    if (slider == &f0Slider)
    {
        // Handle f0Slider changes
        float f0Value = f0Slider.getValue();
        DBG("f0Slider Value: " << f0Value);  // Debug output
        // Optionally, pass this value to the processor or use it directly
    }
    if (slider == &rangeSlider)
    {
        // Handle rangeSlider changes
        float rangeValue = rangeSlider.getValue();
        DBG("rangeSlider Value: " << rangeValue);  // Debug output
        // Optionally, pass this value to the processor or use it directly
    }
    if (slider == &gainSlider)
    {
        float gainValue = gainSlider.getValue();
        DBG("rangeSlider Value: " << gainValue);  // Debug output
        // Optionally, pass this value to the processor or use it directly
    }
}

//==============================================================================
void HasAudioProcessorEditor::changeListenerCallback(juce::ChangeBroadcaster* source)
{
    DBG("$ Broadcasted change");
    if (source == &audioProcessor)
    {
        DBG("$ Change is from HASAP -> attempting graph repainting");
        updateUI();
    }
}

void HasAudioProcessorEditor::updateUI()
{
    DBG("Retrieving data from HASAP");
    // Access points from userParams and update the graphs
    auto amplitudePoints = audioProcessor.getPathPoints("a");
    auto pitchPoints = audioProcessor.getPathPoints("p");
    if (!amplitudePoints.size() || !pitchPoints.size())
    {
        DBG("% INVALID point(s)");
        return;
    }
    
    // Update the graph components
    amplitudeGraph.setPoints(amplitudePoints);
    pitchGraph.setPoints(pitchPoints);
    
    is_updated = true;
}
