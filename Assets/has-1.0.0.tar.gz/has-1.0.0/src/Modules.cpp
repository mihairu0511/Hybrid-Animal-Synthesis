/*
  ==============================================================================

    Modules.cpp
    Created: 25 Oct 2024 3:49:44pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "Modules.h"

Modules::Modules()
{
    models.add(std::make_shared<Mammal>());
    models.add(std::make_shared<Bird>());;
    models.add(std::make_shared<Frog>());;
    
    for (std::shared_ptr<AbstractModel> model : models) {
        if (auto source = dynamic_cast<class SoundSource*>(model.get())) {
            AbstractPart::addInstance(std::shared_ptr<AbstractPart>(model, source), PartType::SoundSource);
            DBG("FOUND -- SOUND SOURCE");
        }
        
        if (auto tract = dynamic_cast<class VocalTract*>(model.get())) {
            AbstractPart::addInstance(std::shared_ptr<AbstractPart>(model, tract), PartType::VocalTract);
            DBG("FOUND -- VOCAL TRACT");
        }
        
        if (auto env = dynamic_cast<class Environment*>(model.get())) {
            AbstractPart::addInstance(std::shared_ptr<AbstractPart>(model, env), PartType::Environment);
            DBG("FOUND -- ENVIRONMENT");
        }
    }
    
    phase = 0;
    
//    setSource(AbstractPart::getInstancesOfType(PartType::SoundSource).getLast());
//    setTract(AbstractPart::getInstancesOfType(PartType::VocalTract).getFirst());
    setEnv(AbstractPart::getInstancesOfType(PartType::Environment).getFirst());
}

void Modules::process(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    if (!source || !tract || !buffer || !params)
    {
//        DBG("zzz... couldn't process");
        return;
    }
    
//    generateSineWave(buffer, numSamples, params);
    
    source->process(buffer, numSamples, params);
    
    applyAmplitudeEnvelope(buffer, numSamples, params);
    
    tract->process(buffer, numSamples, params);

    
    // Ampenv can go here
//    for (int i = 0; i < numSamples; ++i) {
//        float amp = params->getCurrentAmplitude(i);
//        buffer[i] *= amp;
//    }
    
//    if (env)
//        env->process(buffer, numSamples, params);
//    
//    if (!params->isFinished())
//    {
//        DBG("---");
//        DBG("Elapsed time: " << params->getElapsedTime());
//        DBG("Current amplitude (first sample): " << params->getCurrentAmplitude(0.0f));
//    }
}

void Modules::generateSineWave(float* buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    double diff = (2.0f * juce::MathConstants<float>::pi * 440) / params->getSampleRate();
    for (int i = 0; i < numSamples; ++i)
    {
        // Generate a sine wave sample and store it in the buffer.
        buffer[i] = std::sin(phase + i * diff);
        buffer[i] *= 0.5f; // TODO: REMOVE LATER
    }
}

void Modules::applyAmplitudeEnvelope(float* buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    for (int i = 0; i < numSamples; ++i)
    {
        float amp = juce::jlimit(0.0f, 1.0f, params->getCurrentAmplitude(i));
        buffer[i] *= amp;
    }
}

void Modules::setSource(std::shared_ptr<AbstractPart> source)
{
    if (std::shared_ptr<class SoundSource> s = std::dynamic_pointer_cast<class SoundSource>(source))
        this->source = s;
    
}

void Modules::setTract(std::shared_ptr<AbstractPart> tract)
{
    if (std::shared_ptr<class VocalTract> t = std::dynamic_pointer_cast<class VocalTract>(tract))
    {
        this->tract = t;
    }
}

void Modules::setEnv(std::shared_ptr<AbstractPart> env)
{
    if (std::shared_ptr<class Environment> e = std::dynamic_pointer_cast<class Environment>(env))
        this->env = e;
}

std::shared_ptr<AbstractModel> Modules::getSource()
{
    return std::shared_ptr<AbstractModel>(source, dynamic_cast<AbstractModel*>(source.get()));
}

std::shared_ptr<AbstractModel> Modules::getTract()
{
    return std::shared_ptr<AbstractModel>(tract, dynamic_cast<AbstractModel*>(tract.get()));
}

std::shared_ptr<AbstractModel> Modules::getEnv()
{
    return std::shared_ptr<AbstractModel>(env, dynamic_cast<AbstractModel*>(env.get()));
}

void Modules::updatePhase(double sampleRate, int numSamples)
{
    double diff = (2.0f * juce::MathConstants<float>::pi * 440) / sampleRate;
    // Persistent phase across calls - question mark???
    phase = std::fmod(phase + numSamples * diff, 2.0f * juce::MathConstants<float>::pi);
    
}

void Modules::save(juce::ValueTree &state)
{
    juce::ValueTree modulesTree("Modules");
    
    
    if (auto s = getSource())
        modulesTree.setProperty("sourceModel", s->toString(), nullptr);
    
    if (auto t = getTract())
        modulesTree.setProperty("tractModel", t->toString(), nullptr);
    
    if (auto t = getTract())
        modulesTree.setProperty("envModel", t->toString(), nullptr);
    
    state.addChild(modulesTree, 1, nullptr);
    
}

void Modules::load(juce::ValueTree &state)
{
    juce::ValueTree modulesTree = state.getChild(1);
    
    DBG("Attempting to load modules - " + std::to_string(modulesTree.isValid()));
    if (modulesTree.isValid())
    {
        juce::String sourceType = modulesTree.getProperty("sourceModel", "").toString();
        juce::String tractType = modulesTree.getProperty("tractModel", "").toString();
        juce::String envType = modulesTree.getProperty("envModel", "").toString();
        
        DBG("SRC " + sourceType + " TRT " + tractType + " ENV " + envType);
        
        for (std::shared_ptr<AbstractModel> model : models) {
            if (model->toString().equalsIgnoreCase(sourceType))
            {
                DBG("FOUND1");
                setSource(std::shared_ptr<AbstractPart>(model, dynamic_cast<class SoundSource*>(model.get())));
            }
            
            if (model->toString().equalsIgnoreCase(tractType))
            {
                DBG("FOUND2");
                setTract(std::shared_ptr<AbstractPart>(model, dynamic_cast<class VocalTract*>(model.get())));
            }
            
            if (model->toString().equalsIgnoreCase(envType))
            {
                DBG("FOUND3");
                setEnv(std::shared_ptr<AbstractPart>(model, dynamic_cast<class Environment*>(model.get())));
            }
        }
        DBG("Modules loaded successfully");
    }
}
