# HAS (Hybrid Animal Synthesis)
It HAS to be done

# HAS (Hybrid Animal Synthesis) Final Product Plugin

## Table of Contents

- [Milestone Status](#milestone-status)
- [Surprises and Challenges](#surprises-and-challenges)
- [Design and Concept Changes](#design-and-concept-changes)
- [Technical Changes](#technical-changes)
- [Collaboration](#collaboration)

  ## Milestone Status
  The goal of the final product milestone was to build on our beta by implementing drawable envelope boxes, expanding our selection of animal options, and making needed stability improvements.
* Drawable boxes have been implemented
* Additional animal models were not implemented
* Stability improvements have been implemented

  ## Surprises and Challenges

  Unsurprisingly, 1 of the challenges we saw was the implementation of the drawable envelope into the current UI and code. The implementation of UI was challenging because we had to slightly change how the waveform visualizer was implemented. Applying the envelope to actual sound was also challenging for we had to figure out the accessibility of certain variables in certain classes. 
  Another challenge we encountered was difficulty developing and implementing additional sound modules. Existing physical models for animal sounds are complex and feature a wide variety of physics and mathematics concepts which are challenging to recreate in our sound buffer framework. As a compounding factor, we experienced issues moving our previously implemented physical modules from Max/MSP to C++. The implementation of new models was slowed in favor of improving the reliability of the physical models present in our beta release.

  ## Design and Concept Changes

There are no major changes that were made in terms of the inception of the idea; it has been steadily the same concept of hybrid animal synthesis. However, due to its technical difficulties in applying different animal models, we decided to stick to the style of the user choosing the components instead of us preparing prefixes. 

  ## Technical Changes

The primary differences between the beta and final product are a set of minor changes and fixes.

  ## Collaboration
  Working as a group has been extremely smooth. Everyone has been contributing with different emphases based on our individual abilities and strengths and that resulted in everyone making around equal contributions in an effective sense.
