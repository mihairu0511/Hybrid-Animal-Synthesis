/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "Modules.h"
#include "models/Models.h"

//==============================================================================
/**
*/
class HasAudioProcessor  : public juce::AudioProcessor, public juce::ChangeBroadcaster
{
public:
    //==============================================================================
    HasAudioProcessor();
    ~HasAudioProcessor() override;

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    
    juce::AudioBuffer<float> waveformBuffer;
    int waveformBufferWritePos = 0;
    static constexpr int waveformBufferSize = 1024;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;
    
    void initSound(const juce::Array<juce::Point<float>>& amplitudePoints, const juce::Array<juce::Point<float>>& pitchPoints);
    void updatePaths(const juce::Array<juce::Point<float>>& amplitudePoints, const juce::Array<juce::Point<float>>& pitchPoints);
    void notify();
    
    void setSoundSource (int idx);
    void setVocalTract (int idx);
    
    juce::Array<juce::Point<float>> getPathPoints(juce::String type);

private:
    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HasAudioProcessor)
    
    
    juce::HashMap<PartType, juce::Array<std::shared_ptr<AbstractPart>>> parts;
    
    // This can't be initialized until prepareToPlay, hence needs to be managed seperately from class construction
    std::shared_ptr<UserParams> userParams;
    
    // Can be called in constructor
    std::unique_ptr<Modules> modules;
    
    double currentPhase = 0.0f;
    
    
    
};
