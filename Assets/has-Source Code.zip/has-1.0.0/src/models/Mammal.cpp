/*
  ==============================================================================

    Mammal.cpp
    Created: 24 Oct 2024 1:50:10pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "Mammal.h"

Mammal::Mammal() 
{
    // Initialize filters
    for (int i = 0; i < numFilters; ++i) {
//        tractFilters.add(std::make_unique<juce::dsp::IIR::Filter<float>>());
        tractFilters.push_back(std::make_unique<juce::dsp::IIR::Filter<float>>());
//        tractFilters.add(new juce::dsp::IIR::Filter<float>());
    }
}

Mammal::~Mammal()
{
    DBG("Descructing Mammal...");
    // TODO: Figure out why Mammal and Bird filters are leaking in memory
    
    // Clear array memory spots
    for (auto& filter : tractFilters) {
        filter.reset();
    }
    tractFilters.clear();
}

void Mammal::generateSound(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    // Generate phasor
    phasor(buffer, numSamples, params);
    	
    // Temporary buffer for parallel processing
    float* tempBufferA = new float[numSamples];
    for (int i = 0; i < numSamples; ++i) {
        tempBufferA[i] = std::cos(getCordRipple() * buffer[i]);
    }
    
    for (int i = 0; i < numSamples; ++i) {
        buffer[i] = 0.5 * (std::cos(2 * juce::MathConstants<double>::pi * buffer[i]) + 1.0);
    }
    
    
    for (int i = 0; i < numSamples; ++i) {
        // Multiply buffer and tempBufferA
        buffer[i] *= tempBufferA[i];
        
        // Multiply with arg 2?
        buffer[i] *= getCordWidth();
        
        // Square output
        buffer[i] *= buffer[i];
        
        // This does some sort of tame distortion
        buffer[i] = 1 / (buffer[i] + 1);
    }
    
    delete[] tempBufferA;
}

void Mammal::modifySoundThroughTract(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    for (int i = 0; i < numSamples; ++i) {
        // Step 1: set parameters on a per sample basis
        
        double currFreq = getTractBase() + params->getCurrentPitch(i) * getTractBaseMod(); // I2
        double currMod = getTractLength() + params->getCurrentPitch(i) * getTractLengthMod(); // I3
        double currRes = getTractRes() + params->getCurrentPitch(i) * getTractLengthMod(); // I4
        
        // Step 2: Modify filters based on input + parameters
        
        tractFilters[0]->coefficients = juce::dsp::IIR::Coefficients<float>::makeBandPass(params->getSampleRate(), currFreq, currRes);
        
        currFreq += currMod;
        tractFilters[1]->coefficients = juce::dsp::IIR::Coefficients<float>::makeBandPass(params->getSampleRate(), currFreq, currRes);
        
        currFreq += 1.0f;
        tractFilters[2]->coefficients = juce::dsp::IIR::Coefficients<float>::makeBandPass(params->getSampleRate(), currFreq, currRes);
        
        currFreq += 1.0f;
        tractFilters[3]->coefficients = juce::dsp::IIR::Coefficients<float>::makeBandPass(params->getSampleRate(), currFreq, currRes);
        
        currFreq += 1.0f;
        tractFilters[4]->coefficients = juce::dsp::IIR::Coefficients<float>::makeBandPass(params->getSampleRate(), currFreq, currRes);
        
        currFreq += 1.0f;
        tractFilters[5]->coefficients = juce::dsp::IIR::Coefficients<float>::makeBandPass(params->getSampleRate(), currFreq, currRes);
        
        currFreq += 1.0f;
        tractFilters[6]->coefficients = juce::dsp::IIR::Coefficients<float>::makeBandPass(params->getSampleRate(), currFreq, currRes);
        
        currMod *= 8.0f;
        currFreq += currMod;
        tractFilters[7]->coefficients = juce::dsp::IIR::Coefficients<float>::makeBandPass(params->getSampleRate(), currFreq, currRes);
        
        // STEP 3: Apply filters in parallel to the buffer
        
        float res = 0.0f;
        
//        DBG("INPUT: " << buffer[i]);;
        for (int j = 0; j < numFilters; ++j) {
            res += tractFilters[j]->processSample((buffer[i]));
//            DBG(j << ": " << res);
        }
        
        
        buffer[i] = res * 8;
    }
}

void Mammal::phasor(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    static double phase = 0.0f;
    static double phaseOffset = 0.0f;
    double frequency;
    
    for (int i = 0; i < numSamples; ++i) {
        buffer[i] = phase;
        frequency = getFrequencyBase() + getFrequencyRange() * params->getCurrentPitch(i);
        phaseOffset = fmod(phaseOffset + frequency / params->getSampleRate(), 1.0);
        phase = phaseOffset;
    }
}

juce::String Mammal::toString() const
{
    return "Mammal";
}
