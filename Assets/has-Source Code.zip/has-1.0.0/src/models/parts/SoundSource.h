/*
  ==============================================================================

    SoundSource.h
    Created: 24 Oct 2024 1:48:01pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "AbstractPart.h"
#include "Constants.h"

#pragma once

class SoundSource : public AbstractPart
{
public:
    SoundSource();
    virtual ~SoundSource() = 0;
    
    virtual void generateSound(float* buffer, int numSamples, std::shared_ptr<UserParams> params) = 0;
    
    void process(float *buffer, int numSamples, std::shared_ptr<UserParams> params) override;
    
    PartType getType() override { return PartType::SoundSource; }

protected:
    virtual double getFrequencyBase() const = 0;
    virtual double getFrequencyRange() const = 0;
};
