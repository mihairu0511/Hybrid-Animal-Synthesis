/*
  ==============================================================================

    VocalTract.h
    Created: 24 Oct 2024 1:48:32pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "AbstractPart.h"
#include "Constants.h"

#pragma once
class VocalTract : public AbstractPart
{
public:
    VocalTract();
    virtual ~VocalTract() = 0;
    
    virtual void modifySoundThroughTract(float* buffer, int numSamples, std::shared_ptr<UserParams> params) = 0;
    
    void process(float *buffer, int numSamples, std::shared_ptr<UserParams> params) override;
    
    PartType getType() override { return PartType::VocalTract; }
};

