/*
  ==============================================================================

    VocalTract.cpp
    Created: 24 Oct 2024 1:48:32pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "VocalTract.h"

VocalTract::VocalTract() {}

VocalTract::~VocalTract() {}

void VocalTract::process(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    modifySoundThroughTract(buffer, numSamples, params);
}
