/*
  ==============================================================================

    Parts.h
    Created: 25 Oct 2024 1:16:41pm
    Author:  Jack Hayley

  ==============================================================================
*/

#pragma once

#include "AbstractPart.h"
#include "Constants.h"
#include "Environment.h"
#include "SoundSource.h"
#include "UserParams.h"
#include "VocalTract.h"

