/*
  ==============================================================================

    AbstractPart.cpp
    Created: 9 Oct 2024 1:07:46pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "AbstractPart.h"

AbstractPart::AbstractPart() {}
AbstractPart::~AbstractPart() {}

juce::HashMap<PartType, juce::Array<std::shared_ptr<AbstractPart>>> AbstractPart::instances;

juce::Array<std::shared_ptr<AbstractPart>>& AbstractPart::getInstancesOfType(PartType type)
{
    return instances.getReference(type);
}

void AbstractPart::addInstance(std::shared_ptr<AbstractPart> instance)
{
    addInstance(instance, instance->getType());
}

void AbstractPart::addInstance(std::shared_ptr<AbstractPart> instance, PartType type)
{
    if (!instance)
        return;
    
    if (!instances.contains(type)) {
        instances.set(type, juce::Array<std::shared_ptr<AbstractPart>>());
    }
    
    instances.getReference(type).add(instance);
}
