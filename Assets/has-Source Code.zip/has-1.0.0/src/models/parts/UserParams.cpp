/*
  ==============================================================================

    UserParams.cpp
    Created: 25 Oct 2024 9:33:49am
    Author:  Jack Hayley

  ==============================================================================
*/

#include "UserParams.h"


UserParams::UserParams(double sampleRate)
{
    this->sampleRate = sampleRate;
    
//    amplitude.startNewSubPath(0.0f, 0.0f);
//    amplitude.lineTo(0.5f, 1.0f);
//    amplitude.lineTo(1.0f, 0.0f);
//    amplitude.closeSubPath();
//    
//    totalTime = 1.0f;
//    elapsedTime = totalTime;
    
    totalTime = 2.0f;
    elapsedTime = totalTime;
}

UserParams::~UserParams()
{
    amplitude.clear();
    pitch.clear();
}

void UserParams::setAmplitudePath(const juce::Array<juce::Point<float>>& points)
{
    juce::Path temp;
    temp.clear();
    temp.startNewSubPath(0.0f, 0.0f);

    for (int i = 0; i < points.size(); ++i) // OFF BY ONE 💀
        {
//            DBG(std::to_string(points[i].getX()) + " " + std::to_string(points[i].getY()));
            temp.lineTo(points[i].getX(), points[i].getY());
        }
//    amplitude.lineTo(points[points.size() - 1].getY(), 0.0f);
    temp.closeSubPath();

    amplitudePoints = points;
    amplitude = temp;
//    DBG("Amplitude updated to " << amplitudePoints.size() << " | " << amplitude.toString());
    
//    totalTime = 2.0f;
//    elapsedTime = totalTime;
}

void UserParams::setPitchPath(const juce::Array<juce::Point<float>>& points)
{
    juce::Path temp;
    temp.clear();
    temp.startNewSubPath(0.0f, 0.0f);
        
    for (int i = 0; i < points.size(); ++i) // OFF BY ONE 💀
        {
//            DBG(std::to_string(points[i].getX()) + " " + std::to_string(points[i].getY()));
            temp.lineTo(points[i].getX(), points[i].getY());
        }
    
//    pitch.lineTo(points[points.size() - 1].getY(), 0.0f);
    temp.closeSubPath();
    
    pitchPoints = points;
    pitch = temp;
//    
//    totalTime = 2.0f;
//    elapsedTime = totalTime;
}


int UserParams::updateElapsedTime(double dt)
{
    elapsedTime += (dt / sampleRate);
    if (elapsedTime >= totalTime) {
        elapsedTime = totalTime;
        return 1;
    }
    return 0;
}

float UserParams::getElapsedTime()
{
    return elapsedTime;
}

void UserParams::resetElapsedTime()
{
    elapsedTime = 0.0f;
}

float UserParams::lookaheadElapsedTime(double dt)
{
    return elapsedTime + (dt / sampleRate) >= totalTime ? totalTime : elapsedTime + (dt / sampleRate);
}

float UserParams::getCurrentAmplitude(double dt)
{
    return getY(amplitude, lookaheadElapsedTime(dt));
}

float UserParams::getCurrentPitch(double dt)
{
    return getY(pitch, lookaheadElapsedTime(dt));
}

float UserParams::getY(juce::Path path, float x)
{
    juce::Path pathCheckpoint = path;
//    DBG("Made a checkpoint");
    juce::PathFlatteningIterator iterator(pathCheckpoint, {}, 1.0f / sampleRate);
//    DBG("Successfully made with checkpoint");

    while (iterator.next()) {
       float x1 = iterator.x1, y1 = iterator.y1;
       float x2 = iterator.x2, y2 = iterator.y2;

       if (x >= x1 && x <= x2) {
           float proportion = (x - x1) / (x2 - x1);
//           DBG("X: " << x << " | Y: " <<  y1 + proportion * (y2 - y1));
           return y1 + proportion * (y2 - y1);
       }
    }
//    DBG("X: " << x << " | Y: " << 0);
    return 0.0f;
}

double UserParams::getSampleRate()
{
    return sampleRate;
}

void UserParams::initiate()
{
    DBG("Initiating sound");
    resetElapsedTime();
}

bool UserParams::isFinished()
{
    return elapsedTime >= totalTime;
}

void UserParams::save(juce::ValueTree& state)
{
    juce::ValueTree userParamsTree("UserParams");

    DBG("Serializing paths");

    // Serialize amplitude points as strings
    juce::String amplitudeXStr, amplitudeYStr;
    for (int i = 0; i < amplitudePoints.size(); ++i)
    {
        amplitudeXStr += juce::String(amplitudePoints[i].getX()) + ",";
        amplitudeYStr += juce::String(amplitudePoints[i].getY()) + ",";
    }
    
    DBG("AMPX: " << amplitudeXStr);
    DBG("AMPY: " << amplitudeYStr);
    userParamsTree.setProperty("amplitudeX", amplitudeXStr, nullptr);
    userParamsTree.setProperty("amplitudeY", amplitudeYStr, nullptr);

    // Serialize pitch points as strings
    juce::String pitchXStr, pitchYStr;
    for (int i = 0; i < pitchPoints.size(); ++i)
    {
        pitchXStr += juce::String(pitchPoints[i].getX()) + ",";
        pitchYStr += juce::String(pitchPoints[i].getY()) + ",";
    }

    userParamsTree.setProperty("pitchX", pitchXStr, nullptr);
    userParamsTree.setProperty("pitchY", pitchYStr, nullptr);

    state.addChild(userParamsTree, 0, nullptr);
    
    if (amplitudePoints.isEmpty())
    {
        DBG("Amplitude points are empty during save (BAD).");
    }
    if (pitchPoints.isEmpty())
    {
        DBG("Pitch points are empty during save (BAD).");
    }
    
}

void UserParams::load(juce::ValueTree& state)
{
    DBG("Attempting to load user parameters");
    juce::ValueTree userParamsTree = state.getChildWithName("UserParams");
    if (userParamsTree.isValid())
    {
        // Deserialize amplitude points
        juce::String amplitudeXStr = userParamsTree.getProperty("amplitudeX", "").toString();
        juce::String amplitudeYStr = userParamsTree.getProperty("amplitudeY", "").toString();
        juce::StringArray amplitudeXArray = juce::StringArray::fromTokens(amplitudeXStr, ",", "");
        juce::StringArray amplitudeYArray = juce::StringArray::fromTokens(amplitudeYStr, ",", "");

        amplitudePoints.clear();
        int lim = amplitudeXArray.size(); // 5;
        for (int i = 0; i < lim; ++i)
        {
            amplitudePoints.add({amplitudeXArray[i].getFloatValue(), amplitudeYArray[i].getFloatValue()});
        }
        setAmplitudePath(amplitudePoints);
        

        // Deserialize pitch points
        juce::String pitchXStr = userParamsTree.getProperty("pitchX", "").toString();
        juce::String pitchYStr = userParamsTree.getProperty("pitchY", "").toString();
        juce::StringArray pitchXArray = juce::StringArray::fromTokens(pitchXStr, ",", "");
        juce::StringArray pitchYArray = juce::StringArray::fromTokens(pitchYStr, ",", "");

        pitchPoints.clear();
        
        int lim2 = pitchXArray.size(); // 5;
        for (int i = 0; i < lim2; ++i)
        {
            pitchPoints.add({pitchXArray[i].getFloatValue(), pitchYArray[i].getFloatValue()});
        }
        setPitchPath(pitchPoints);

        DBG("User parameters loaded successfully");
    }
}

juce::Array<juce::Point<float>> UserParams::getPathPoints(juce::Path path)
{
    juce::Array<juce::Point<float>> points;
    juce::PathFlatteningIterator iterator(path, juce::AffineTransform(), 1.0f);
    
    if (!iterator.next())
        return points;
    
    while (iterator.next())
    {
        points.add({iterator.x1, iterator.y1});
    }

    return points;
}

juce::Array<juce::Point<float>> UserParams::getAmplitudePoints()
{
    return amplitudePoints;
}

juce::Array<juce::Point<float>> UserParams::getPitchPoints()
{
    return pitchPoints;
}
