/*
  ==============================================================================

    Environment.h
    Created: 24 Oct 2024 1:48:52pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "AbstractPart.h"
#include "Constants.h"

#pragma once
class Environment : public AbstractPart
{
public:
    virtual ~Environment() = 0;
    
    void process(float* buffer, int numSamples, std::shared_ptr<UserParams> params) override;
    virtual void applyEffectsToSound(float* buffer, int numSamples, std::shared_ptr<UserParams> params) = 0;
    
    PartType getType() override { return PartType::Environment; }
};
