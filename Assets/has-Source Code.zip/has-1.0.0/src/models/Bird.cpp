/*
  ==============================================================================

    Bird.cpp
    Created: 24 Oct 2024 1:50:15pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include "Bird.h"

Bird::Bird() 
{
    // Initialize filters
    for (int i = 0; i < numFilters; ++i) {
        tractFilters.push_back(std::make_unique<juce::dsp::StateVariableTPTFilter<float>>());
        tractFilters.back()->setType(juce::dsp::StateVariableTPTFilterType::bandpass);
    }
}

Bird::~Bird()
{
    DBG("Descructing Bird...");
    // TODO: Figure out why Mammal and Bird filters are leaking in memory
    
    // Clear array memory spots
    for (auto& filter : tractFilters) {
        filter.reset();
    }
    tractFilters.clear();
}

void Bird::generateSound(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    // Dual tract sound generation
    float* tempBufferA = new float[numSamples];
    static double phaseA = 0.0f;
    vposc(tempBufferA, numSamples, params, getFrequencyBase(), getFrequencyRange(), phaseA);
    
    float* tempBufferB = new float[numSamples];
    static double phaseB = 0.0f;
    vposc(tempBufferB, numSamples, params, getFrequencyBase() / 2, getFrequencyRange() / 2, phaseB);
    
    // Syrinx processing
    for (int i = 0; i < numSamples; ++i) {
        // Parallel process
        float lProcess = (tempBufferA[i] + tempBufferB[i]) * getSyrinxModRatio();
        float rProcess = (tempBufferA[i] * tempBufferB[i]) * (1 / getSyrinxModRatio());
        buffer[i] = ((lProcess + rProcess) * getSyrinxModFrequency()) + getSyrinxBaseFrequency();
    }
    
    static double phaseC = 0.0f;
    vposc(buffer, numSamples, params, getSyrinxPulseWidth(), phaseC);
    
    delete[] tempBufferA;
    delete[] tempBufferB;
}

void Bird::modifySoundThroughTract(float *buffer, int numSamples, std::shared_ptr<UserParams> params)
{
    for (int i = 0; i < numSamples; ++i) {
        // Step 1: set parameters on a per sample basis (same as mammal apparently? investigate later...)
        
        double currFreq = getTractBase() + params->getCurrentPitch(i) * getTractBaseMod(); // I2
        double currMod = getTractLength() + params->getCurrentPitch(i) * getTractLengthMod(); // I3
        double currRes = getTractRes() + params->getCurrentPitch(i) * getTractLengthMod(); // I4
        
        // Step 2: configure filters
        
        tractFilters[0]->setCutoffFrequency(currFreq);
        tractFilters[0]->setResonance(currRes);
        
        tractFilters[1]->setCutoffFrequency(currMod);
        tractFilters[1]->setResonance(currRes);
        
        // Step 3: Apply filters in parallel to the buffer
        
        // Do processing of filters per sample here (assume they were defined in constructor)
        
        float res = 0.0f;
        
        for (int j = 0; j < numFilters; ++j) {
            res += tractFilters[j]->processSample(0, buffer[i]);
        }
        
        buffer[i] = res * 1 / 3.5;
    }
    
}

void Bird::vposc(float *buffer, int numSamples, std::shared_ptr<UserParams> params, double freq, double mod, double& phase)
{
    
    double phaseIncrement = (2.0 * juce::MathConstants<double>::pi * freq) / params->getSampleRate();

    for (int i = 0; i < numSamples; ++i)
    {
        // Generate sine wave
        buffer[i] = std::sin(phase);
        
        // Add variable pulse
        buffer[i] *= mod;
        
        // Math math math
        buffer[i] *= buffer[i];
        buffer[i] = 1 / (buffer[i] + 1);
        
        
        // Increment phase
        phase += phaseIncrement;
        
        // Wrap phase to avoid overflow and ensure continuity
        if (phase >= 2.0 * juce::MathConstants<double>::pi)
            phase -= 2.0 * juce::MathConstants<double>::pi;
    }
}

void Bird::vposc(float *buffer, int numSamples, std::shared_ptr<UserParams> params, double mod, double& phase)
{
    for (int i = 0; i < numSamples; ++i)
    {
        double phaseIncrement = (2.0 * juce::MathConstants<double>::pi * buffer[i]) / params->getSampleRate();
        
        // Generate sine wave
        buffer[i] = std::sin(phase);
        
        // Add variable pulse
        buffer[i] *= mod;
        
        // Math math math
        buffer[i] *= buffer[i];
        buffer[i] = 1 / (buffer[i] + 1);
        
        
        // Increment phase
        phase += phaseIncrement;
        
        // Wrap phase to avoid overflow and ensure continuity
        if (phase >= 2.0 * juce::MathConstants<double>::pi)
            phase -= 2.0 * juce::MathConstants<double>::pi;
    }
}

juce::String Bird::toString() const
{
    return "Bird";
}
