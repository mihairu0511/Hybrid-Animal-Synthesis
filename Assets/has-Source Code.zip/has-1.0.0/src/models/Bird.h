/*
  ==============================================================================

    Bird.h
    Created: 24 Oct 2024 1:50:15pm
    Author:  Jack Hayley

  ==============================================================================
*/

#include <juce_dsp/juce_dsp.h>

#include "parts/SoundSource.h"
#include "parts/VocalTract.h"
#include "AbstractModel.h"

#pragma once

class Bird : public AbstractModel, public SoundSource, public VocalTract {
    
    
public:
    Bird();
    ~Bird();
    
//    void process(float* buffer, int numSamples, PartType type) override;
    void generateSound(float* buffer, int numSamples, std::shared_ptr<UserParams> params) override;
    void modifySoundThroughTract(float* buffer, int numSamples, std::shared_ptr<UserParams> params) override;
    
    juce::String toString() const override;

protected:
    double getFrequencyBase() const override { return 40.0; };
    double getFrequencyRange() const override { return 5.0; };
    
    double getSyrinxModRatio() const { return 0.8; };
    double getSyrinxModFrequency() const { return 600.0; };
    double getSyrinxBaseFrequency() const { return 600.0; };
    double getSyrinxPulseWidth() const { return 3.0; };
    
    double getTractBase() const { return 338.0; };
    double getTractLength() const { return 124.0; };
    double getTractRes() const { return 44.4; };
    double getTractBaseMod() const { return 180.0; };
    double getTractLengthMod() const { return 41.0; };
    double getTractResMod() const { return 26.0; };

private:
    std::vector<std::unique_ptr<juce::dsp::StateVariableTPTFilter<float>>> tractFilters;
    int numFilters = 2;
    
    void vposc(float* buffer, int numSamples, std::shared_ptr<UserParams> params, double freq, double mod, double& phase);
    void vposc(float* buffer, int numSamples, std::shared_ptr<UserParams> params, double mod, double& phase);
};
