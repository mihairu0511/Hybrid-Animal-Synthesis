/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "DraggableLineGraph.h"

//==============================================================================
/**
*/
class HasAudioProcessorEditor  : public juce::AudioProcessorEditor, public juce::ChangeListener, public juce::Button::Listener, private juce::Timer, juce::Slider::Listener
{
public:
    HasAudioProcessorEditor (HasAudioProcessor&);
    ~HasAudioProcessorEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;

    void buttonClicked(juce::Button* button) override;
    void sliderValueChanged(juce::Slider* slider) override;
    
    //==============================================================================
    void changeListenerCallback(juce::ChangeBroadcaster* source) override;
    
private:
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    HasAudioProcessor& audioProcessor;
    
    // Test button for now (remove later)
    
    void timerCallback() override;
    
    void updateUI();
    
    juce::TextButton initButton { "Play" };
    juce::TextButton cowSourceButton { "Cow" };
    juce::TextButton cowTractButton { "Cow" };
    juce::TextButton birdSourceButton { "Bird" };
    juce::TextButton birdTractButton { "Bird" };
    juce::TextButton frogSourceButton { "Frog" };
    juce::TextButton caveButton { "Cave" };
    
    juce::Slider f0Slider, rangeSlider, gainSlider;
    
    juce::Path waveformPath;
    
    DraggableLineGraph amplitudeGraph;
    DraggableLineGraph pitchGraph;
    
    bool is_updated = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HasAudioProcessorEditor)
};
