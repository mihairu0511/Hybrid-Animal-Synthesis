# HAS (Hybrid Animal Synthesis) Beta Plugin

## Table of Contents

- [Milestone Status](#milestone-status)
- [Surprises and Challenges](#surprises-and-challenges)
- [Design and Concept Changes](#design-and-concept-changes)
- [Technical Changes](#technical-changes)
- [Remaining Work](#remaining-works)
- [Collaboration](#collaboration)

  ## Milestone Status

  The goal of the beta plugin milestone was to convert the MVP max patch into actual audio plugin using JUCE framework, [which most part is completed](has.jucer). The plugin has the similar functionality as the MVP:
* Works in digital audio workstation
* 2 sound sources (a vocal cord modeling approach and a karplus-strong blown tube approach)
* 2 vocal tract (cow, general bird)


  ## Surprises and Challenges

  Unsurprisingly, 1 of the challenge we saw was the translation of the code. Converting a visual language to C++ had multiple technical challenges, such as lack of real time processing, lack of native visual patching environment, and memory management. Memory leaks were also significant and unique challenge we faced when converting the code. Below is the conversion example.

![alt text](./images/max.jpg)
![alt text](./images/c++.jpg)

  ## Design and Concept Changes

  There are no major changes that were made in terms of the inception of the idea; it has been steadily the same concept of hybrid animal synthesis. We are still in the phase of users choosing the components and controlling some parameters, but are planning to change direction to have just premade presets to simplify the product usage as much as possible. We are still planning to implement the controllable input for amplitude and pitch using drawable boxes. 

  ## Technical Changes

  There were no change in the technical framework and languages that we were planning to use. Using C++ and JUCE gives us much more flexibility and modularity in terms of variable and function use. 

  ## Remaining Works

  In terms of remaining works, we still need to design and create more vocal tract and sound source options to create variety of presets that could simplify the overall user experience with remaining modularity. Additionally, we need to figure out how to normalize audio coming into/out of vocal tract processing, and also need to finish implementing the controllable inputs for amplitude and pitch using drawable boxes for unique sound designs. Reducing memory leak is another step we have to take as well. 

  ## Collaboration

  Working as a group has been extremely smooth. Everyone has been contributing with different emphases based on our individual abilities and strengths and that resulted in everyone making around equal contributions in an effective sense.

